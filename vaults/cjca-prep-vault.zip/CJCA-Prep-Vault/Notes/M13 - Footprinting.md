---
module: Footprinting
number: 13
difficulty: Medium
sections: 21
academy: https://academy.hackthebox.com/course/preview/footprinting
status: not-started
tags: [cjca, module]
---

> [!info] At a glance
> Used in: <!-- link the methodology phase(s) where you use this -->
> HTB Academy: https://academy.hackthebox.com/course/preview/footprinting

## Summary
<!-- 2-3 lines: what this module teaches and when you'd use it -->

## Commands
```bash
# command            # what it does
```

## Tools
- 

## Gotchas / Lessons Learned
- 

## Links
- Methodology: [[00 - Attack Flow (MOC)]]
- Index: [[00 - Module Index (MOC)]]
