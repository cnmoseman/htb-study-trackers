---
module: Web Requests
number: 8
difficulty: Fundamental
sections: 8
academy: https://academy.hackthebox.com/course/preview/web-requests
status: not-started
tags: [cjca, module]
---

> [!info] At a glance
> Used in: <!-- link the methodology phase(s) where you use this -->
> HTB Academy: https://academy.hackthebox.com/course/preview/web-requests

## Summary
<!-- 2-3 lines: what this module teaches and when you'd use it -->

## Commands
```bash
# command            # what it does
```

## Tools
- 

## Gotchas / Lessons Learned
- 

## Links
- Methodology: [[00 - Attack Flow (MOC)]]
- Index: [[00 - Module Index (MOC)]]
