---
tags: [cwpe, moc]
cssclasses: [cwpe-hub]
---

![[cwpe-art.png|banner]]

# CWPE Prep Vault

Certified Wi-Fi Pentesting Expert. This vault holds your methodology, module notes and exam workspace. Open this folder as an Obsidian vault (**Open folder as vault**).

> [!abstract] The exam
> CWPE is a 7-day wireless exam in HTB's cloud lab, so you don't need your own hardware. You attack a real-world wireless setup: WEP, WPA, WPA2 and WPA3 networks, captive portals, and a corporate Wi-Fi network that leads into Active Directory. Flags prove each step, and you finish with a commercial-grade report.

Four parts:

- **[[00 - Attack Flow (MOC)]]**: your methodology, as numbered blank phases that you name and fill in your own way.
- **[[00 - Module Index (MOC)]]**: your notes, one per Academy module, in course order. Your methodology links back to these.
- **[[00 - Exam (MOC)]]**: your exam workspace, with networks and hosts, credentials, findings, flags and a log for each day, laid out like the report.
- **[CWPE Study Tracker](https://cnmoseman.github.io/htb-study-trackers/cwpe/tracker/)**: the day-by-day study plan for this cert. Check off tasks there as you go.

> [!warning] Read this first
> CWPE launched in 2026 and nobody has published an exam write-up yet. Lean on the last module, Attacking Corporate Wi-Fi Networks, which runs a full engagement end to end, and practice the report before you book.

> [!tip] Do the reporting module
> Do the [Documentation & Reporting](https://academy.hackthebox.com/course/preview/documentation--reporting) module from the Penetration Tester path before your exam, even though it isn't in the CWPE path. It shows you how to take notes during an engagement and turn them into the kind of report HTB grades. It's built around the CPTS report, so it won't match the CWPE report one for one. Take the general tips and good habits from it and apply them to the CWPE report template.

## How to use it
1. Work through the course in order. As you finish each module, fill in its note.
2. Build your methodology as you go. Rename each `Fill in` phase to a step in your own workflow, and add or delete phases as you need. New phases use `Templates/Methodology Phase`.
3. Fill each phase with your own checklist, commands and decision points, and link back to the module notes with `[[...]]`.
4. Keep one note per tool in `Notes/Tools` and one per protocol in `Notes/Protocols`, made from `Templates/Tool` and `Templates/Protocol`. [[Aircrack-ng]] and [[WPS]] are there to start you off. Link them from your module notes and phases so the commands you use most are one click away.
5. Each module note has one heading per Academy section. Use the **Outline** pane on the right to jump between them, and click the arrow by a heading to fold it.
6. On exam day, start at [[00 - Exam (MOC)]] and work from your methodology. The exam notes are bookmarked on the left. `Ctrl+click` any `[[link]]` to open the note behind it.

## Command sources
Get tested commands from these as you go:
- [V0lk3n wireless cheat sheet](https://github.com/V0lk3n/WirelessPentesting-CheatSheet)
- [armourinfosec wireless cheat sheet](https://github.com/armourinfosec/Wireless-Security-and-WiFi-Penetration-Testing)
- [HackTricks Wi-Fi methodology](https://hacktricks.wiki/en/generic-methodologies-and-resources/pentesting-wifi/index.html)
- Reporting: [SysReptor HTB-CWPE template](https://docs.sysreptor.com/assets/reports/HTB-CWPE-Report.pdf) + [Documentation & Reporting module](https://academy.hackthebox.com/course/preview/documentation--reporting)

---
<span style="color: var(--text-faint)">Made by</span> [cnmoseman](https://github.com/cnmoseman) · [All HTB Study Trackers](https://cnmoseman.github.io/htb-study-trackers/) · [Report a problem](https://github.com/cnmoseman/htb-study-trackers/issues/new?template=report-problem.yml&cert=CWPE&where=Prep+notes&title=%5BProblem%5D+%5BCWPE%5D+)
