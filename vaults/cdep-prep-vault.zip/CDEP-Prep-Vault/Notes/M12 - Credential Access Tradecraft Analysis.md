---
module: Credential Access Tradecraft Analysis
number: 12
difficulty: Hard
sections: 21
academy: https://academy.hackthebox.com/course/preview/credential-access-tradecraft-analysis
status: not-started
tags: [cdep, module]
---

> [!info] At a glance
> Used in: <!-- link the methodology phase(s) where you use this -->
> HTB Academy: https://academy.hackthebox.com/course/preview/credential-access-tradecraft-analysis

## Summary
<!-- 2-3 lines: what this module teaches and when you'd use it -->

## Commands
```bash
# command            # what it does
```

## Tools
- 

## Gotchas / Lessons Learned
- 

## Links
- Methodology: [[00 - Investigation Flow (MOC)]]
- Index: [[00 - Module Index (MOC)]]
