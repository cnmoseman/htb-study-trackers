---
module: Detecting Access Token Manipulation Attacks
number: 7
difficulty: Hard
sections: 17
academy: https://academy.hackthebox.com/course/preview/detecting-access-token-manipulation-attacks
status: not-started
tags: [cdep, module]
---

> [!info] At a glance
> Used in: <!-- link the methodology phase(s) where you use this -->
> HTB Academy: https://academy.hackthebox.com/course/preview/detecting-access-token-manipulation-attacks

## Summary
<!-- 2-3 lines: what this module teaches and when you'd use it -->

## Commands
```bash
# command            # what it does
```

## Tools
- 

## Gotchas / Lessons Learned
- 

## Links
- Methodology: [[00 - Investigation Flow (MOC)]]
- Index: [[00 - Module Index (MOC)]]
