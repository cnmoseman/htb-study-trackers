---
module: Incident Handling Process
number: 1
difficulty: Easy
sections: 11
academy: https://academy.hackthebox.com/course/preview/incident-handling-process
status: not-started
tags: [cdsa, module]
---

> [!info] At a glance
> Used in: <!-- link the methodology phase(s) where you use this -->
> HTB Academy: https://academy.hackthebox.com/course/preview/incident-handling-process

## Summary
<!-- 2-3 lines: what this module teaches and when you'd use it -->

## Commands
```bash
# command            # what it does
```

## Tools
- 

## Gotchas / Lessons Learned
- 

## Links
- Methodology: [[00 - Investigation Flow (MOC)]]
- Index: [[00 - Module Index (MOC)]]
