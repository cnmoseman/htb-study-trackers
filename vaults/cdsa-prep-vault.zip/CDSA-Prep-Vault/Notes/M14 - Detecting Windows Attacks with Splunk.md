---
module: Detecting Windows Attacks with Splunk
number: 14
difficulty: Medium
sections: 23
academy: https://academy.hackthebox.com/course/preview/detecting-windows-attacks-with-splunk
status: not-started
tags: [cdsa, module]
---

> [!info] At a glance
> Used in: <!-- link the methodology phase(s) where you use this -->
> HTB Academy: https://academy.hackthebox.com/course/preview/detecting-windows-attacks-with-splunk

## Summary
<!-- 2-3 lines: what this module teaches and when you'd use it -->

## Commands
```bash
# command            # what it does
```

## Tools
- 

## Gotchas / Lessons Learned
- 

## Links
- Methodology: [[00 - Investigation Flow (MOC)]]
- Index: [[00 - Module Index (MOC)]]
