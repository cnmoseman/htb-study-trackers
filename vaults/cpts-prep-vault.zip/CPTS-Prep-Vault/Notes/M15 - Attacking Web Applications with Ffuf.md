---
module: Attacking Web Applications with Ffuf
number: 15
difficulty: Easy
sections: 13
academy: https://academy.hackthebox.com/course/preview/attacking-web-applications-with-ffuf
status: not-started
tags: [cpts, module]
---

> [!info] At a glance
> Used in: <!-- link the methodology phase(s) where you use this -->
> HTB Academy: https://academy.hackthebox.com/course/preview/attacking-web-applications-with-ffuf

## Summary
<!-- 2-3 lines: what this module teaches and when you'd use it -->

## Commands
```bash
# command            # what it does
```

## Tools
- 

## Gotchas / Lessons Learned
- 

## Links
- Methodology: [[00 - Attack Flow (MOC)]]
- Index: [[00 - Module Index (MOC)]]
