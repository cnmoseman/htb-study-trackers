---
module: Web Attacks
number: 23
difficulty: Medium
sections: 18
academy: https://academy.hackthebox.com/course/preview/web-attacks
status: not-started
tags: [cpts, module]
---

> [!info] At a glance
> Used in: <!-- link the methodology phase(s) where you use this -->
> HTB Academy: https://academy.hackthebox.com/course/preview/web-attacks

## Summary
<!-- 2-3 lines: what this module teaches and when you'd use it -->

## Commands
```bash
# command            # what it does
```

## Tools
- 

## Gotchas / Lessons Learned
- 

## Links
- Methodology: [[00 - Attack Flow (MOC)]]
- Index: [[00 - Module Index (MOC)]]
